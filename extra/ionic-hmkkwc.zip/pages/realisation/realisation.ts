import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-realisation',
  templateUrl: 'realisation.html'
})
export class RealisationPage {

  constructor(public navCtrl: NavController) {

  }

}
